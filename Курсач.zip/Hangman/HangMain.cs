﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Hangman
{
    public partial class HangMain : Form
    {
        public HangMain()
        {
            InitializeComponent();
            this.FormClosing += Confirmation; // вызывает форму подтверждения*
            this.FormClosed += HangMain_FormClosed; // закрытие формы вызывает выход из приложения*
        }

        private void HangMain_FormClosed(object sender, FormClosedEventArgs e) // *закрытие формы вызывает выход из приложения
        {
            Application.Exit();
        }

        private void Confirmation(object sender, CancelEventArgs e)
        {   
            var result = MessageBox.Show("Вы действительно хотите выйти?", "Выход", MessageBoxButtons.YesNo); // *подтверждение выхода
            if (result == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e) => this.Close(); // закрывает форму и вызывает соответствующие события, приводящие к выходу

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e) // о программе
        {
            About about = new About();
            about.ShowDialog();
        }

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e) // новая игра
        {
            int difficulty = 7; // хардкод под сегменты будущей картинки
            int tries = 0; // 
            bool won = false;
            char guess = 'q'; // временный обход ошибки !!!добавить отдельную функцию считывания попыток!!!
            string[] dictionary = File.ReadAllLines("c:\\q\\dictionary.txt"); // словарь
            Random random = new Random();
            string word = dictionary[random.Next(0, dictionary.Length)]; // текущее слово
            current_line.Text = ""; // сброс лейбла
            for (int i = 0; i < word.Length; i++)
            {
                current_line.Text += "*"; // заполнение лейбла неотгаданными буквами
            }
            while (!won)
            {
                if (open(guess, word))
                {
                    for (int i = 0; i < word.Length; i++)
                    {
                        current_line.Text = guess + current_line.Text.Remove(i, 1); // замена "*" на отгаданную букву
                    }   // НЕТ — засрёт всю строку одной буквой — ИСПРАВИТЬ!!!
                }
                else
                {
                    tries++;
                }
                if (tries >= difficulty)
                {
                    // добавить состояние проигрыша
                    break;
                }
                else
                {
                    // добавить проверку на состояние выигрыша
                }

            }
            // не забыть запретить отгадывать букву дважды
        }
        public bool open(char guess, string word) // функция Якубовича
        {
            bool found = false;
            for (int i = 0; i < word.Length; i++)
            {
                if (guess == word[i])
                {
                    found = true; // откройте букву guess
                    break;
                }
            }
            return found;
        }
        public char let(object sender)
        {
            char result;
            if (sender == b1)
            {
                result = 'А';
            }
            else if (sender == b2)
            {
                result = 'Б';
            }
            else if (sender == b3)
            {
                result = 'В';
            }
            else if (sender == b4)
            {
                result = 'Г';
            }
            else if (sender == b5)
            {
                result = 'Д';
            }
            else if (sender == b6)
            {
                result = 'Е';
            }
            else if (sender == b7)
            {
                result = 'Ё';
            }
            else if (sender == b8)
            {
                result = 'Ж';
            }
            else if (sender == b9)
            {
                result = 'З';
            }
            else if (sender == b10)
            {
                result = 'И';
            }
            else if (sender == b11)
            {
                result = 'Й';
            }
            else if (sender == b12)
            {
                result = 'К';
            }
            else if (sender == b13)
            {
                result = 'Л';
            }
            else if (sender == b14)
            {
                result = 'М';
            }
            else if (sender == b15)
            {
                result = 'Н';
            }
            else if (sender == b16)
            {
                result = 'О';
            }
            else if (sender == b17)
            {
                result = 'П';
            }
            else if (sender == b18)
            {
                result = 'Р';
            }
            else if (sender == b19)
            {
                result = 'С';
            }
            else if (sender == b20)
            {
                result = 'Т';
            }
            else if (sender == b21)
            {
                result = 'У';
            }
            else if (sender == b22)
            {
                result = 'Ф';
            }
            else if (sender == b23)
            {
                result = 'Х';
            }
            else if (sender == b24)
            {
                result = 'Ц';
            }
            else if (sender == b25)
            {
                result = 'Ч';
            }
            else if (sender == b26)
            {
                result = 'Ш';
            }
            else if (sender == b27)
            {
                result = 'Щ';
            }
            else if (sender == b28)
            {
                result = 'Ъ';
            }
            else if (sender == b29)
            {
                result = 'Ы';
            }
            else if (sender == b30)
            {
                result = 'Ь';
            }
            else if (sender == b31)
            {
                result = 'Э';
            }
            else if (sender == b32)
            {
                result = 'Ю';
            }
            else if (sender == b33)
            {
                result = 'Я';
            }
            else
            {
                return '\0';
            }
            return result;
        }

        private void b1_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b2_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b3_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b4_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b5_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b6_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b7_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b8_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b9_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b10_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b11_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b12_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b13_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b14_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b15_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b16_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b17_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b18_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b19_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b20_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b21_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b22_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b23_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b24_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b25_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b26_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b27_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b28_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b29_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b30_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b31_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b32_Click(object sender, EventArgs e)
        {
            let(sender);
        }

        private void b33_Click(object sender, EventArgs e)
        {
            let(sender);
        }
    }

}
